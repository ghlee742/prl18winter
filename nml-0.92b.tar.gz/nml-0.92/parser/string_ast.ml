(*
 Jungtaek Kim

 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

module Ast =
Ast_gen.Ast_generator(Info.StringInfo)(Info.LocationInfo)

