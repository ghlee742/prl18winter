(*
 Kwangkeun Yi
   
 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

(* Definitions for interoperation from N to OCaml *)
(* The interoperation is via common types of N and OCaml *)  

(* Lexing_to_lex_tables coerces string tuples into Lexing.lex_tables *)
let lexing_to_lex_tables (s1,s2,s3,s4,s5) =
  {
   Lexing.lex_base = s1;
   Lexing.lex_backtrk = s2;
   Lexing.lex_default = s3;
   Lexing.lex_trans = s4;
   Lexing.lex_check = s5
  }

let lexing_field_refill_buff lexbuf = lexbuf.Lexing.refill_buff    
let lexing_field_lex_buffer lexbuf = lexbuf.Lexing.lex_buffer
let lexing_field_lex_buffer_len lexbuf = lexbuf.Lexing.lex_buffer_len
let lexing_field_lex_abs_pos lexbuf = lexbuf.Lexing.lex_abs_pos
let lexing_field_lex_start_pos lexbuf = lexbuf.Lexing.lex_start_pos
let lexing_field_lex_curr_pos lexbuf = lexbuf.Lexing.lex_curr_pos
let lexing_field_lex_last_pos lexbuf = lexbuf.Lexing.lex_last_pos
let lexing_field_lex_last_action lexbuf = lexbuf.Lexing.lex_last_action
let lexing_field_lex_eof_reached lexbuf = lexbuf.Lexing.lex_eof_reached

let lexing_field_update_lex_buffer (lexbuf,x) = lexbuf.Lexing.lex_buffer <- x
let lexing_field_update_lex_buffer_len (lexbuf,x) = lexbuf.Lexing.lex_buffer_len <- x
let lexing_field_update_lex_abs_pos (lexbuf,x) = lexbuf.Lexing.lex_abs_pos <- x
let lexing_field_update_lex_start_pos (lexbuf,x) = lexbuf.Lexing.lex_start_pos <- x
let lexing_field_update_lex_curr_pos (lexbuf,x) = lexbuf.Lexing.lex_curr_pos <- x
let lexing_field_update_lex_last_pos (lexbuf,x) = lexbuf.Lexing.lex_last_pos <- x
let lexing_field_update_lex_last_action (lexbuf,x) = lexbuf.Lexing.lex_last_action <- x
let lexing_field_update_lex_eof_reached (lexbuf,x) = lexbuf.Lexing.lex_eof_reached <- x

