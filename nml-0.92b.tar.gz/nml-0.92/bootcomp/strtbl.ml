(*
 Hyunjun Eo

 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

(* Based on Objective Caml Code                            *)

open String_ast.Ast

let str_table = (Hashtbl.create 101 : (string, string) Hashtbl.t)
let sig_table = (Hashtbl.create 101 : (string, string) Hashtbl.t)
let fct_table = (Hashtbl.create 101 : (string, string) Hashtbl.t)

let str_add hashtbl a b =
  try let x = Hashtbl.find hashtbl a in
      (prerr_string ("Warning: structure "^a^
                     " is duplicated in more than one file.\n");
       if x = "." then 
         (Hashtbl.remove hashtbl a;
          Hashtbl.add hashtbl a b;
          Hashtbl.add hashtbl a x)
       else Hashtbl.add hashtbl a b)
  with Not_found -> Hashtbl.add hashtbl a b

let sig_add hashtbl a b =
  try let x = Hashtbl.find hashtbl a in
      (prerr_string ("Warning: signature "^a^
                     " is duplicated in more than one file.\n");
       if x = "." then
         (Hashtbl.remove hashtbl a;
          Hashtbl.add hashtbl a b;
          Hashtbl.add hashtbl a x)
       else Hashtbl.add hashtbl a b)
  with Not_found -> Hashtbl.add hashtbl a b

let fct_add hashtbl a b =
  try let x = Hashtbl.find hashtbl a in
      (prerr_string ("Warning: functor "^a^
                     " is duplicated in more than one file.\n");
       if x = "." then
         (Hashtbl.remove hashtbl a;
          Hashtbl.add hashtbl a b;
          Hashtbl.add hashtbl a x)
       else Hashtbl.add hashtbl a b)
  with Not_found -> Hashtbl.add hashtbl a b

let foreach_file fname self = begin
  let module_name = (Filename.chop_suffix (Filename.basename fname) ".n") in
  let build_from_sigbind ((id,_),_,_) =
    if self then sig_add sig_table id "."
    else sig_add sig_table id module_name
  in
  let build_from_strbind ((id,_),_,_,_) =
    if self then str_add str_table id "."
    else str_add str_table id module_name
  in
  let build_from_sig (sblist,_) = List.iter build_from_sigbind sblist
  in
  let build_from_fct ((id,_),_,_,_,_) =
    if self then fct_add fct_table id "."
    else fct_add fct_table id module_name
  in
  let rec build_from_str st =
    match st with
      SimpleDec (d,_) -> ()
    | StrDec (sblist,_) -> List.iter build_from_strbind sblist
    | SeqStrDec (sdlist,_) -> List.iter build_from_str sdlist
  in
  let rec foreach_topdec ast =
    match ast with
      Sig (sg,_) -> build_from_sig sg 
    | Fct (ft,_) -> build_from_fct ft
    | Str (st,_) -> build_from_str st
    | SeqTopDec (tdl,_) -> List.iter foreach_topdec tdl
  in
  let inputfile = fname in
  let ic = open_in_bin inputfile in
  let ast =
    try
      seek_in ic 0;
      Location.input_name := inputfile;
      Nparse.parse (Lexing.from_channel ic)
    with x -> close_in ic; raise x
  in
  let _ = close_in ic in
    foreach_topdec ast
  end

let build_str_table sourcefile = begin
  let nfiles = open_in ".files" in
  let fname = ref "" in
    try
      while (fname := input_line nfiles; true) do
        if (Filename.check_suffix (!fname) ".n")
        then
        try
          foreach_file (!fname)
            ((Filename.basename sourcefile) = (Filename.basename (!fname)))
        with _ -> ()
        else ()
      done
    with
      End_of_file -> ()
    | _ -> ()
  end
