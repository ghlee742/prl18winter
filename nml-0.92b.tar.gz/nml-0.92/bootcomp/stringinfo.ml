(*
 Oukseh Lee

 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

module StringInfo = struct
     type varidinfo = string
     type tyidinfo = string
     type conidinfo = string
     type stridinfo = string
     type sigidinfo = string
     type fctidinfo = string
     type labelinfo = string
     type tyvarinfo = string
     let print_varidinfo = Format.printf "%s"
     let print_tyidinfo = Format.printf "%s"
     let print_conidinfo = Format.printf "%s"
     let print_stridinfo = Format.printf "%s"
     let print_sigidinfo = Format.printf "%s"
     let print_fctidinfo = Format.printf "%s"
     let print_labelinfo = Format.printf "%s"
     let print_tyvarinfo = Format.printf "%s"
end

module LocationInfo = struct
  type info = Location.t
  let print x = Location.print Format.std_formatter x
  let loc i = i
end
