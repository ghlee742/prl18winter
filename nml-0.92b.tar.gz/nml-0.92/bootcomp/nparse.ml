
(*
 JungTaek Kim

 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

open Location

let batch_parse lexbuf = 
  try
    let ast = Nparser.batch_parse Nlexer.token lexbuf in
    Postparse.check_error ast;
    Parsing.clear_parser();
    ast
  with
      Nlexer.Error(Nlexer.Unterminated_comment, _, _) as err -> raise err
    | Nlexer.Error(Nlexer.Unterminated_string, _, _) as err -> raise err
    | Nlexer.Error(_, _, _) as err -> raise err
    | Nsyntaxerr.Error _ as err -> raise err
    | Parsing.Parse_error | Nsyntaxerr.Escape_error ->
        let loc = { loc_start = Lexing.lexeme_start lexbuf;
                    loc_end = Lexing.lexeme_end lexbuf;
                    loc_ghost = false } in
        raise(Nsyntaxerr.Error(Nsyntaxerr.Other(loc,Nsyntaxerr.UnknownError)))

(*
let interactive_parse lexbuf = 
  try
    let ast = Nparser.interactive_parse Nlexer.token lexbuf in
    Postparse.check_topdec ast;
    Parsing.clear_parser();
    ast
  with
      Nlexer.Error(Nlexer.Unterminated_comment, _, _) as err -> raise err
    | Nlexer.Error(Nlexer.Unterminated_string, _, _) as err -> raise err
    | Nlexer.Error(_, _, _) as err -> raise err
    | Nsyntaxerr.Error _ as err -> raise err
    | Parsing.Parse_error | Nsyntaxerr.Escape_error ->
        let loc = { loc_start = Lexing.lexeme_start lexbuf;
                    loc_end = Lexing.lexeme_end lexbuf;
                    loc_ghost = false } in
        raise(Nsyntaxerr.Error(Nsyntaxerr.Other(loc,Nsyntaxerr.UnknownError)))


let toplevel_parse =  interactive_parse
*)
let implementation_parse = batch_parse
let parse = batch_parse

