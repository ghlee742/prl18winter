#include <stdio.h>
#include <tcl.h>

main ()
{
    puts(TCL_VERSION);
}
