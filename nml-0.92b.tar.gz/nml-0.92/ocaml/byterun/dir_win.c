/***********************************************************************/
/*                                                                     */
/*                           Objective Caml                            */
/*                                                                     */
/*             Pascal Cuoq, projet Cristal, INRIA Rocquencourt         */
/*                                                                     */
/*  Copyright 1996 Institut National de Recherche en Informatique et   */
/*  en Automatique.  All rights reserved.  This file is distributed    */
/*  under the terms of the GNU Library General Public License, with    */
/*  the special exception on linking described in file ../../LICENSE.  */
/*                                                                     */
/***********************************************************************/

/* $Id: dir_win.c,v 1.1.1.1 2002/01/16 09:01:26 cookcu Exp $ */

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#ifndef HAS_UI
#include <io.h>
#endif
#include "mlvalues.h"
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include "memory.h"
#include "misc.h"
#include "osdeps.h"
#include "signals.h"
#include <errno.h>

/*
#include <wtypes.h>
#include <winbase.h>
#include <stdlib.h>
#include "io.h"
#include <direct.h>
#include <process.h>
#include "mlvalues.h"
#include "memory.h"
#include "alloc.h"
*/

CAMLprim value nml_opendir(path)
  value path;
{
  fatal_error("Compiler bug: nml_opendir");
}

CAMLprim value nml_readdir(path)
  value path;
{
  fatal_error("Compiler bug: nml_readdir");
}

CAMLprim value nml_closedir(path)
  value path;
{
  fatal_error("Compiler bug: nml_closedir");
}

CAMLprim value nml_findfirst(name)
     value name;
{
  int h;
  value v;
  struct _finddata_t fileinfo;
  value valname = Val_unit;

  Begin_root (valname);
    h = _findfirst(String_val(name),&fileinfo);
    if (h == -1) {
      if (errno == ENOENT)
        raise_end_of_file();
      else
	    raise_not_found();
    }
    valname = copy_string(fileinfo.name);
    v = alloc_small(2, 0);
    Field(v,0) = valname;
    Field(v,1) = Val_int(h);
  End_roots();
  return v;
}

CAMLprim value nml_findnext(valh)
     value valh;
{
  int retcode;
  struct _finddata_t fileinfo;

  retcode = _findnext(Int_val(valh), &fileinfo);
  if (retcode != 0) raise_end_of_file();
  return copy_string(fileinfo.name);
}

CAMLprim value nml_findclose(valh)
     value valh;
{
  if (_findclose(Int_val(valh)) != 0) raise_not_found();
  return Val_unit;
}

