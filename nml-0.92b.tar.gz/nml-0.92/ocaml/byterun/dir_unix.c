
#include "mlvalues.h"
#include "fail.h"
#include "alloc.h"
#include <sys/types.h>
#ifdef HAS_DIRENT
#include <dirent.h>
typedef struct dirent directory_entry;
#else
#include <sys/dir.h>
typedef struct direct directory_entry;
#endif

CAMLprim value nml_opendir(value path)
{
  DIR * d;
  d = opendir(String_val(path));
  if (d == (DIR *) NULL) raise_not_found();
  return (value) d;
}


CAMLprim value nml_readdir(value d)
{
  directory_entry * e;

  e = readdir((DIR *) d);
  if (e == (directory_entry *) NULL) raise_end_of_file();
  return copy_string(e->d_name);
}

CAMLprim value nml_closedir(value d)
{
  closedir((DIR *) d);
  return Val_unit;
}

CAMLprim value nml_findfirst(name)
  value name;
{
  fatal_error("Compiler bug: nml_win_findfirst");
}

CAMLprim value nml_findnext(valh)
  value valh;
{
  fatal_error("Compiler bug: nml_win_findnext");
}

CAMLprim value nml_findclose(valh)
  value valh;
{
  fatal_error("Compiler bug: nml_win_findclose");
}
