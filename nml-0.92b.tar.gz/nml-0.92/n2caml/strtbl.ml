(*
 Hyunjun Eo

 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

(* Based on Objective Caml Code                            *)

let str_table = (Hashtbl.create 101 : (string, string) Hashtbl.t)
let sig_table = (Hashtbl.create 101 : (string, string) Hashtbl.t)
let fct_table = (Hashtbl.create 101 : (string, string) Hashtbl.t)

let str_add hashtbl a b =
  try let x = Hashtbl.find hashtbl a in
      (prerr_string ("Warning: structure "^a^
                     " is duplicated in more than one file.\n");
       if x = "." then 
         (Hashtbl.remove hashtbl a;
          Hashtbl.add hashtbl a b;
          Hashtbl.add hashtbl a x)
       else Hashtbl.add hashtbl a b)
  with Not_found -> Hashtbl.add hashtbl a b

let sig_add hashtbl a b =
  try let x = Hashtbl.find hashtbl a in
      (prerr_string ("Warning: signature "^a^
                     " is duplicated in more than one file.\n");
       if x = "." then
         (Hashtbl.remove hashtbl a;
          Hashtbl.add hashtbl a b;
          Hashtbl.add hashtbl a x)
       else Hashtbl.add hashtbl a b)
  with Not_found -> Hashtbl.add hashtbl a b

let fct_add hashtbl a b =
  try let x = Hashtbl.find hashtbl a in
      (prerr_string ("Warning: functor "^a^
                     " is duplicated in more than one file.\n");
       if x = "." then
         (Hashtbl.remove hashtbl a;
          Hashtbl.add hashtbl a b;
          Hashtbl.add hashtbl a x)
       else Hashtbl.add hashtbl a b)
  with Not_found -> Hashtbl.add hashtbl a b

