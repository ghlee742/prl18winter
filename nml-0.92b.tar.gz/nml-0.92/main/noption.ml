(*
 Oukseh Lee

 This source is almost copied from the Objective Caml compiler.
*)



(***********************************************************************)
(*                                                                     *)
(*                           Objective Caml                            *)
(*                                                                     *)
(*            Xavier Leroy, projet Cristal, INRIA Rocquencourt         *)
(*                                                                     *)
(*  Copyright 1996 Institut National de Recherche en Informatique et   *)
(*  en Automatique.  All rights reserved.  This file is distributed    *)
(*  under the terms of the Q Public License version 1.0.               *)
(*                                                                     *)
(***********************************************************************)
let print_standard_library () =
  print_string Config.standard_library; print_newline(); exit 0

module OptionsFn = functor(K :
sig 
  val impl : string -> unit
  val intf : string -> unit
  val anonymous : string -> unit
  val print_version_number : unit -> unit
end) ->
struct
  open Config
  open Clflags
  open Main_args
  module A = Make_options (struct
    let set r () = r := true
    let unset r () = r := false
    let _a = set make_archive
    let _c = set compile_only
    let _cc s = c_compiler := s; c_linker := s
    let _cclib s = ccobjs := s :: !ccobjs
    let _ccopt s = ccopts := s :: !ccopts
    let _custom = set custom_runtime
    let _dllib s = dllibs := s :: !dllibs
    let _dllpath s = dllpaths := !dllpaths @ [s]
    let _g = set debug
    let _i = set print_types
    let _I s = include_dirs := s :: !include_dirs
    let _impl = K.impl
    let _intf = K.intf
    let _intf_suffix s = Config.interface_suffix := s
    let _labels = unset classic
    let _linkall = set link_everything
    let _make_runtime () =
           custom_runtime := true; make_runtime := true; link_everything := true
    let _noassert = set noassert
    let _noautolink = set no_auto_link
    let _nolabels = set classic
    let _o s = exec_name := s; archive_name := s; object_name := s
    let _output_obj () = output_c_object := true; custom_runtime := true
    let _pp s = preprocessor := Some s
    let _rectypes = set recursive_types
    let _thread = set thread_safe
    let _unsafe = set fast
    let _use_prims s = use_prims := s
    let _use_runtime s = use_runtime := s
    let _v = K.print_version_number
    let _w = Warnings.parse_options false
    let _warn_error = (Warnings.parse_options true)
    let _where = print_standard_library
    let _verbose = set verbose
    let _nopervasives = set nopervasives
    let _dparsetree = set dump_parsetree
    let _drawlambda = set dump_rawlambda
    let _dlambda = set dump_lambda
    let _dinstr = set dump_instr
    let _ntyping s = ntyping := s
    let anonymous = K.anonymous
  end)

  let list = A.list
end
