(*
 Oukseh Lee

 Copyright(c) 2000-2004 KAIST/SNU Research On Program Analysis System
 (National Creative Research Initiative Center 1998-2003)
 http://ropas.snu.ac.kr/n

 All rights reserved. This file is distributed under the terms of
 an Open Source License.
*)

    type 'a ty =
          NtSome
        | NtData of 'a ty list * 'a
        | NtTuple of 'a ty list
        | NtRec of (string * 'a ty) list
    type 'a nty = 'a ty 
                  * ('a -> 'a ty list -> string -> 'a ty list)
                  * (Longident.t -> 'a ty)

